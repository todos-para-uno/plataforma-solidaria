<?php
define('ES_RETORNO', true);
require __DIR__ . '/index.php';

<?php
declare(strict_types=1);
ini_set('display_errors', '0');
header('Cache-Control: no-store, private');
header('Referrer-Policy: no-referrer');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-Robots-Tag: noindex, nofollow');
header("Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'");
$config = require __DIR__ . '/config.php';
$base = rtrim($config['url_base'], '/');
$retorno = $base . '/retorno.php';
if (strtolower($_SERVER['HTTP_HOST'] ?? '') !== strtolower((string) parse_url($base, PHP_URL_HOST))) {
    http_response_code(400);
    exit('Abrí esta prueba desde el dominio HTTPS configurado en config.php.');
}
session_name('MP_HOSTING_PRUEBA');
session_set_cookie_params(['lifetime' => 0, 'path' => rtrim((string) parse_url($base, PHP_URL_PATH), '/') . '/', 'secure' => true, 'httponly' => true, 'samesite' => 'Lax']);
ini_set('session.use_strict_mode', '1');
if (!session_start()) {
    http_response_code(500);
    exit('No se pudo iniciar la sesión PHP. Revisá su configuración en el hosting.');
}
function e(string $value): string { return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function fecha(int $time): string {
    return (new DateTimeImmutable('@' . $time))->setTimezone(new DateTimeZone('America/Argentina/Buenos_Aires'))->format('Y-m-d H:i:s P');
}
$_SESSION['csrf'] ??= bin2hex(random_bytes(32));
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if (!in_array($method, ['GET', 'POST'], true) || (defined('ES_RETORNO') && $method !== 'GET')) {
    header('Allow: GET' . (defined('ES_RETORNO') ? '' : ', POST'));
    http_response_code(405);
    exit('Método no permitido.');
}
if (defined('ES_RETORNO')) {
    $pending = $_SESSION['pendiente'] ?? null;
    $state = $_GET['state'] ?? null;
    if (!is_array($pending) || !is_string($state) || !hash_equals($pending['state'], $state) || time() - $pending['creado'] > 600) {
        $_SESSION['resultado'] = 'Retorno rechazado: la sesión o el state no coinciden, o el intento venció. Volvé a iniciar la prueba en este navegador.';
    } else {
        unset($_SESSION['pendiente']);
        if (isset($_GET['error'])) {
            $_SESSION['resultado'] = 'El retorno llegó con state válido, pero Mercado Pago informó un error o una autorización cancelada.';
        } elseif (is_string($_GET['code'] ?? null) && $_GET['code'] !== '' && strlen($_GET['code']) <= 2048) {
            $_SESSION['resultado'] = 'Llegó un retorno con state válido y un código de autorización. No guardamos ni mostramos ese código. Esta prueba no lo intercambia por tokens ni comprueba pagos.';
        } else {
            $_SESSION['resultado'] = 'El retorno llegó con state válido, pero sin un código de autorización válido.';
        }
    }
    $_SESSION['hora_retorno'] = time();
    // Quitar los parámetros del navegador. No guardar ni imprimir code o verifier.
    header('Location: ' . $base . '/', true, 303);
    exit;
}
if ($method === 'POST') {
    if (!is_string($_POST['csrf'] ?? null) || !hash_equals($_SESSION['csrf'], $_POST['csrf'])) {
        http_response_code(403);
        exit('Formulario vencido. Recargá la página.');
    }
    session_regenerate_id(true);
    $state = bin2hex(random_bytes(32));
    $verifier = rtrim(strtr(base64_encode(random_bytes(48)), '+/', '-_'), '=');
    $_SESSION['pendiente'] = ['state' => $state, 'verifier' => $verifier, 'creado' => time()];
    $_SESSION['informe'] = ['state' => $state, 'creado' => time(), 'retorno' => $retorno, 'client_id' => $config['client_id']];
    unset($_SESSION['resultado'], $_SESSION['hora_retorno']);
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
    header('Location: ' . $base . '/', true, 303);
    exit;
}
$pending = $_SESSION['pendiente'] ?? null;
$url = null;
if (is_array($pending) && time() - $pending['creado'] <= 600) {
    $url = 'https://auth.mercadopago.com.ar/authorization?' . http_build_query([
        'client_id' => $config['client_id'], 'response_type' => 'code', 'platform_id' => 'mp',
        'redirect_uri' => $retorno, 'state' => $pending['state'],
        'code_challenge' => rtrim(strtr(base64_encode(hash('sha256', $pending['verifier'], true)), '+/', '-_'), '='),
        'code_challenge_method' => 'S256',
    ]);
}
$informe = $_SESSION['informe'] ?? null;
?>
<!doctype html>
<html lang="es-AR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Prueba OAuth · todospara.uno</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#f7f5f0;color:#12385b;font:17px/1.6 system-ui,sans-serif}main{max-width:820px;margin:40px auto;padding:24px}section{background:#fffefa;border:1px solid #ccc7bc;border-radius:12px;padding:24px;margin:24px 0;box-shadow:5px 5px #ecd89f}h1{font-family:Georgia,serif;line-height:1.2}h2{font-size:1.2rem}button,.boton{display:inline-block;padding:12px 20px;background:#12385b;color:white;border:0;border-radius:6px;font:inherit;cursor:pointer;text-decoration:none}code,pre{overflow-wrap:anywhere;white-space:pre-wrap}code{font-size:.9em}a{color:#12385b}.resultado{border-left:5px solid #2f6b3f}small{display:block;margin-top:12px}button:focus-visible,a:focus-visible{outline:3px solid #b8472b;outline-offset:4px}
</style></head><body><main>
<h1>Prueba de conexión con Mercado Pago</h1>
<p>Esta página comprueba si podemos superar la autorización del vendedor desde el hosting. No realiza cobros ni vincula cuentas a la plataforma.</p>
<section><h2>1. Configuración del retorno</h2><p>Agregá esta dirección en las URLs de redireccionamiento de la aplicación, manteniendo PKCE activado:</p><code><?= e($retorno) ?></code><p>Aplicación: <code><?= e($config['client_id']) ?></code></p></section>
<?php if (isset($_SESSION['resultado'])): ?><section class="resultado"><h2>Resultado del retorno</h2><p><?= e($_SESSION['resultado']) ?></p><p>Recibido: <?= e(fecha($_SESSION['hora_retorno'])) ?> — America/Argentina/Buenos_Aires.</p></section><?php endif; ?>
<section><h2>2. Preparar un intento nuevo</h2><p>Usá el mismo vendedor de prueba que falló en el entorno local. Un intento nuevo reemplaza al anterior en este navegador.</p><form method="post" action="<?= e($base) ?>/"><input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>"><button type="submit">Preparar intento</button></form>
<?php if ($url !== null): ?><p><a class="boton" href="<?= e($url) ?>" rel="noreferrer">Continuar a Mercado Pago</a></p><small>Continuá antes de 10 minutos. Si aparece el error, anotá la hora y volvé con el botón Atrás para copiar los datos.</small><?php endif; ?></section>
<?php if (is_array($informe)): ?><section><h2>Datos del último intento preparado</h2><p>Podés compartir estos datos en el ticket privado. Completá la hora del error y el nickname que efectivamente usaste.</p><pre><?= e('Hora de preparación: ' . fecha($informe['creado']) . "\nZona horaria: America/Argentina/Buenos_Aires\nClient ID: " . $informe['client_id'] . "\nredirect_uri: " . $informe['retorno'] . "\nstate: " . $informe['state'] . "\nPKCE: code_challenge enviado, code_challenge_method=S256\nHora del error: [completar]\nNickname del vendedor: [completar]") ?></pre></section><?php endif; ?>
<p><small>El resultado solo confirma la recepción del retorno. El canje del código, la comprobación de PKCE durante ese canje y los pagos quedan fuera de esta prueba. Ningún código recibido se considera un pago confirmado.</small></p>
</main></body></html>

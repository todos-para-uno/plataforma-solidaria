<?php
// Solo datos públicos. Esta prueba NO usa Client Secret ni Access Tokens.
return [
    'client_id' => '6921561117397304',
    'url_base' => 'https://todospara.uno/prueba-mp',
];
